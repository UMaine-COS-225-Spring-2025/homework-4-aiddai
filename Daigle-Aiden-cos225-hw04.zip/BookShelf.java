import java.util.ArrayList;

public class BookShelf {
    
    public char letter;
    
    public ArrayList<Book> bookList = new ArrayList<>();

    public BookShelf(char letterIn){
        letter = letterIn;
        for(int i = 0; i < 8; i++){
            bookList.add(null); // default initializes the arraylist with null. null == no book
        }
    }
    
    public void addBook(Book bookObj){
        if(bookObj.title.charAt(0)!=letter){
            int i = bookList.indexOf(null);
            if(i!=-1){
                bookList.set(i,bookObj);
            }
        }
    }
    public void rmBook(int index) {
        if(bookList.get(index)!=null){
            bookList.set(index,null);
        }
    }

    @Override

    public String toString(){
        int count = 0;
        String books = "";
        for(int i = 0; i < 8 ;i++){
            if(bookList.get(i)!=null){
                books+=bookList.get(i).title+"   ";
            }   else {
                count++;
            }
        if(count==8){
            return "Empty";
        }
        }
        return books;
    }

    public static void main(String[] args){
        
    }
}