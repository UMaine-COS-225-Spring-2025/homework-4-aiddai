public class LibraryTester {
    
    public static void main(String[] args){
        BookShelf shelfO = new BookShelf('O');
        BookShelf shelfT = new BookShelf('T');

        System.out.println(shelfO);
        System.out.println(shelfT);

        Book book1 = new Book("The Heart of the Betrayed", "Crime");
        Book book2 = new Book("Our Hill of Stars", "Fantasy");
        Book book3 = new Book("One of a Kind", "Science Fiction");
        Book book4 = new Book("The Vision of Roses", "Romance");

        Book[] bookList = {book1, book2, book3, book4};

        for (int i = 0; i < 4; i++){
            System.out.println(bookList[i]);
            shelfO.addBook(bookList[i]);
            shelfT.addBook(bookList[i]);
        }

        System.out.println(shelfO);
        System.out.println(shelfT);
    }
}
